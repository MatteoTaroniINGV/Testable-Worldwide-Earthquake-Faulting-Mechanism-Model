"Final_Model.txt" format:

columns from 1 to 10:

  1       2
Long and Lat of the center of the i-th spatial cell

3 5 7 9         4 6 8 10
Long      and   Lat        of the vertices of the i-th spatial cell


columns from 11 to 138:

parameters of the Dirichlet distribution for the 128 combinations of the angles; the order of the combinations is the same of the "Angles_Combinations.txt" file.






"Angles_Combinations.txt" format:

columns are the centres of the intervals for:

   1       2      3 
 Strike   Dip    Rake

lines from 1 to 128 corresponds to the columns from 11 to 138 in the "Final_Model.txt" file.






"CMT_Catalog.txt" format:

each line respresents one seismic event, icluding the angles (in degree) of the first and second nodal plane; the columns are:
  1   2    3     4   5           6              7        8     9      10       11     12   13       14    15   16
Long Lat Year Month Day   Magnitude (Mw)   Depth (Km)   Hour Minure Second  Strike1  Dip1 Rake1  Strike2 Dip2 Rake2





"Testing_Catalog.txt' format:

each line respresents one seismic event, icluding the angles (in degree) of the preferred nodal plane; the columns are:
  1   2    3     4   5           6                         7        8     9      10      11     12   13  
Long Lat Year Month Day   Scalar Moment (10^20 N*m)   Depth (Km)   Hour Minure Second  Strike   Dip  Rake






  