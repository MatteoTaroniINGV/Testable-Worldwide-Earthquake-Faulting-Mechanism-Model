"Final_Model.txt" format:

columns from 1 to 10:

  1       2
Long and Lat of the center of the i-th spatial cell

3 5 7 9         4 6 8 10
Long      and   Lat        of the vertices of the i-th spatial cell


columns from 11 to 138:

parameters of the Dirichlet distribution for the 128 combinations of the angles; the order of the combinations is the same of the "Angles_Combinations.txt" file.






"Angles_Combinations.txt" format:

columns are the centres of the intervals for:

   1       2      3 
 Strike   Dip    Rake

lines from 1 to 128 corresponds to the columns from 11 to 138 in the "Final_Model.txt" file.







  